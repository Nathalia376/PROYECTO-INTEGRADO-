from django.shortcuts import render
from django.db import models
from django.core.exceptions import ObjectDoesNotExist

# Create your views here.
def home(request):
    login_name = ''
    user = request.session.get('id')

    if user:
        try:
            user = models.User.objects.get(id=user)
            login_name = user.username
        except ObjectDoesNotExist:
            pass  # Si el usuario no existe, login_name seguirá siendo ''
        return render(request, '/home.html', {"name":login_name})

  
"""
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from .models import User

# Vista para listar usuarios
class UserListView(ListView):
    model = User
    template_name = 'user_list.html'  # Ruta al template
    context_object_name = 'users'

# Vista para crear un usuario
class UserCreateView(CreateView):
    model = User
    template_name = 'user_form.html'  # Ruta al formulario
    fields = ['user', 'nombre', 'apellido', 'correo', 'contrasena']
    success_url = reverse_lazy('user-list')

# Vista para actualizar un usuario
class UserUpdateView(UpdateView):
    model = User
    template_name = 'user_form.html'
    fields = ['user', 'nombre', 'apellido', 'correo', 'contrasena']
    success_url = reverse_lazy('user-list')

# Vista para eliminar un usuario
class UserDeleteView(DeleteView):
    model = User
    template_name = 'user_confirm_delete.html'  # Confirmación de eliminación
    success_url = reverse_lazy('user-list')"
"""