from django.db import models

class User(models.Model):
    user = models.CharField(verbose_name='Usuario',max_length=10,unique=True,  null=False,blank=False)
    nombre = models.CharField(verbose_name='Nombre', max_length=30, null=False, blank=False)
    apellido= models.CharField(verbose_name='Apellido', max_length=30, null=False, blank=False)
    correo = models.EmailField(verbose_name='Correo', max_length=30, null=False, blank=False)
    contrasena = models.CharField(max_length=30, null=False, blank=False)

    def __str__(self):
        return f'{self.user}-{self.nombre}-{self.apellido}'
    class Meta:
        ordering = ['id']



    
